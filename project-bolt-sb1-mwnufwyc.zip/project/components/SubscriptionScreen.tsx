import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { CreditCard, Check, Calendar } from 'lucide-react-native';
import { useAuth } from '../hooks/useAuth';

export function SubscriptionScreen() {
  const { startSubscription, user, isTrialActive, trialEndDate } = useAuth();

  const handleSubscribe = async () => {
    Alert.alert(
      'Subscribe',
      'Subscribe for ₹2000/year to access the Steel Rate Calculator?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Subscribe', onPress: startSubscription },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <View style={styles.iconContainer}>
          <CreditCard size={60} color="#2563eb" />
        </View>
        
        <Text style={styles.title}>Premium Access Required</Text>
        <Text style={styles.subtitle}>
          {isTrialActive 
            ? `Your trial expires on ${trialEndDate}. Subscribe to continue using all features.`
            : 'Your free trial has ended. Subscribe to continue using the Steel Rate Calculator.'
          }
        </Text>

        {isTrialActive && (
          <View style={styles.trialStatus}>
            <Text style={styles.trialStatusText}>
              Free Trial Active Until: {trialEndDate}
            </Text>
          </View>
        )}

        <View style={styles.priceContainer}>
          <Text style={styles.currency}>₹</Text>
          <Text style={styles.price}>2000</Text>
          <Text style={styles.period}>/ year</Text>
        </View>

        <View style={styles.featuresContainer}>
          <View style={styles.feature}>
            <Check size={20} color="#16a34a" />
            <Text style={styles.featureText}>Complete steel rate calculations</Text>
          </View>
          <View style={styles.feature}>
            <Check size={20} color="#16a34a" />
            <Text style={styles.featureText}>GST calculations with breakdown</Text>
          </View>
          <View style={styles.feature}>
            <Check size={20} color="#16a34a" />
            <Text style={styles.featureText}>Invoice generation</Text>
          </View>
          <View style={styles.feature}>
            <Check size={20} color="#16a34a" />
            <Text style={styles.featureText}>PDF export functionality</Text>
          </View>
          <View style={styles.feature}>
            <Check size={20} color="#16a34a" />
            <Text style={styles.featureText}>Multiple calculation modes</Text>
          </View>
        </View>

        <TouchableOpacity style={styles.subscribeButton} onPress={handleSubscribe}>
          <Text style={styles.subscribeButtonText}>
            {isTrialActive ? 'Upgrade to Premium' : 'Subscribe Now'}
          </Text>
        </TouchableOpacity>

        <View style={styles.securityNote}>
          <Text style={styles.securityText}>
            Secure payment processing with industry-standard encryption
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
    alignItems: 'center',
  },
  iconContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#eff6ff',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 22,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 32,
  },
  currency: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2563eb',
  },
  price: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#2563eb',
  },
  period: {
    fontSize: 18,
    color: '#6b7280',
    marginLeft: 4,
  },
  featuresContainer: {
    alignSelf: 'stretch',
    marginBottom: 32,
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureText: {
    fontSize: 16,
    color: '#374151',
    marginLeft: 12,
  },
  subscribeButton: {
    backgroundColor: '#2563eb',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
    alignItems: 'center',
    alignSelf: 'stretch',
    marginBottom: 16,
  },
  subscribeButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '600',
  },
  securityNote: {
    alignItems: 'center',
  },
  securityText: {
    fontSize: 12,
    color: '#9ca3af',
    textAlign: 'center',
  },
  trialStatus: {
    backgroundColor: '#fef3c7',
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#fbbf24',
  },
  trialStatusText: {
    fontSize: 14,
    color: '#92400e',
    textAlign: 'center',
    fontWeight: '600',
  },
});