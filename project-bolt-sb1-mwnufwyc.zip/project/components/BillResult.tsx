import React from 'react';
import {
  View,
  Text,
  StyleSheet,
} from 'react-native';
import { FileText } from 'lucide-react-native';

interface BillResultProps {
  result: {
    mode: string;
    customerName: string;
    phoneNumber: string;
    invoiceDate: string;
    invoiceNumber: string;
    vehicleNumber: string;
    finalRateThin: string;
    finalRateThick: string;
    quantities: {
      qty6mm: number;
      qty8mm: number;
      qty10mm: number;
      qty12mm: number;
      qty16mm: number;
      qty20mm: number;
      qty25mm: number;
    };
    totals: {
      total6mm: string;
      total8mm: string;
      total10mm: string;
      total12mm: string;
      total16mm: string;
      total20mm: string;
      total25mm: string;
    };
    beforeGST: string;
    cgst: string;
    sgst: string;
    subTotal: string;
  };
}

export function BillResult({ result }: BillResultProps) {
  const { mode, quantities, totals } = result;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <FileText size={24} color="#2563eb" />
        <Text style={styles.headerText}>Calculation Result</Text>
      </View>

      {mode !== 'onlyrate' && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Invoice Details</Text>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Invoice Number:</Text>
            <Text style={styles.detailValue}>{result.invoiceNumber}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Date:</Text>
            <Text style={styles.detailValue}>{result.invoiceDate}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Customer Name:</Text>
            <Text style={styles.detailValue}>{result.customerName}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Phone:</Text>
            <Text style={styles.detailValue}>{result.phoneNumber}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Vehicle No:</Text>
            <Text style={styles.detailValue}>{result.vehicleNumber}</Text>
          </View>
        </View>
      )}

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Rates</Text>
        <View style={styles.rateRow}>
          <Text style={styles.rateLabel}>6–8mm Rate:</Text>
          <Text style={styles.rateValue}>₹{result.finalRateThin}</Text>
        </View>
        <View style={styles.rateRow}>
          <Text style={styles.rateLabel}>10–25mm Rate:</Text>
          <Text style={styles.rateValue}>₹{result.finalRateThick}</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Quantities & Totals</Text>
        {[
          { size: '6mm', qty: quantities.qty6mm, total: totals.total6mm },
          { size: '8mm', qty: quantities.qty8mm, total: totals.total8mm },
          { size: '10mm', qty: quantities.qty10mm, total: totals.total10mm },
          { size: '12mm', qty: quantities.qty12mm, total: totals.total12mm },
          { size: '16mm', qty: quantities.qty16mm, total: totals.total16mm },
          { size: '20mm', qty: quantities.qty20mm, total: totals.total20mm },
          { size: '25mm', qty: quantities.qty25mm, total: totals.total25mm },
        ].map(({ size, qty, total }) => 
          qty > 0 && (
            <View key={size} style={styles.quantityRow}>
              <Text style={styles.quantityLabel}>{size}:</Text>
              <Text style={styles.quantityValue}>{qty} tons</Text>
              <Text style={styles.quantityTotal}>₹{total}</Text>
            </View>
          )
        )}
      </View>

      {mode !== 'onlyrate' && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>GST Breakdown</Text>
          <View style={styles.gstRow}>
            <Text style={styles.gstLabel}>Amount Before GST:</Text>
            <Text style={styles.gstValue}>₹{result.beforeGST}</Text>
          </View>
          <View style={styles.gstRow}>
            <Text style={styles.gstLabel}>CGST (9%):</Text>
            <Text style={styles.gstValue}>₹{result.cgst}</Text>
          </View>
          <View style={styles.gstRow}>
            <Text style={styles.gstLabel}>SGST (9%):</Text>
            <Text style={styles.gstValue}>₹{result.sgst}</Text>
          </View>
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total Amount:</Text>
            <Text style={styles.totalValue}>₹{result.subTotal}</Text>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginLeft: 8,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    paddingBottom: 4,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  detailLabel: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
  },
  detailValue: {
    fontSize: 14,
    color: '#111827',
    fontWeight: '600',
  },
  rateRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
    backgroundColor: '#f0f9ff',
    padding: 8,
    borderRadius: 8,
  },
  rateLabel: {
    fontSize: 14,
    color: '#2563eb',
    fontWeight: '600',
  },
  rateValue: {
    fontSize: 14,
    color: '#2563eb',
    fontWeight: 'bold',
  },
  quantityRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
    paddingVertical: 4,
  },
  quantityLabel: {
    fontSize: 14,
    color: '#374151',
    fontWeight: '500',
    flex: 1,
  },
  quantityValue: {
    fontSize: 14,
    color: '#6b7280',
    flex: 1,
    textAlign: 'center',
  },
  quantityTotal: {
    fontSize: 14,
    color: '#111827',
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
  gstRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  gstLabel: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
  },
  gstValue: {
    fontSize: 14,
    color: '#111827',
    fontWeight: '600',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  totalLabel: {
    fontSize: 16,
    color: '#111827',
    fontWeight: 'bold',
  },
  totalValue: {
    fontSize: 16,
    color: '#2563eb',
    fontWeight: 'bold',
  },
});