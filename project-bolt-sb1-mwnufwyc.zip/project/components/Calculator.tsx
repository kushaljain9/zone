import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { Calculator as CalculatorIcon, Download } from 'lucide-react-native';
import { BillResult } from './BillResult';
import { usePDFGeneration } from '../hooks/usePDFGeneration';

export function Calculator() {
  const [billMode, setBillMode] = useState('bill');
  const [formData, setFormData] = useState({
    customerName: '',
    phoneNumber: '',
    invoiceDate: '',
    invoiceNumber: '',
    vehicleNumber: '',
    basicRate: '',
    qty6mm: '',
    qty8mm: '',
    qty10mm: '',
    qty12mm: '',
    qty16mm: '',
    qty20mm: '',
    qty25mm: '',
  });
  const [result, setResult] = useState<any>(null);
  const { generatePDF } = usePDFGeneration();

  const handleModeChange = (mode: string) => {
    setBillMode(mode);
    if (mode === 'without') {
      setFormData(prev => ({
        ...prev,
        customerName: 'N/A',
        phoneNumber: '0000000000',
        invoiceDate: new Date().toISOString().split('T')[0],
        invoiceNumber: 'N/A',
        vehicleNumber: 'N/A',
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        customerName: '',
        phoneNumber: '',
        invoiceDate: '',
        invoiceNumber: '',
        vehicleNumber: '',
      }));
    }
  };

  const calculateBill = () => {
    const basicRate = parseFloat(formData.basicRate);
    const qty6mm = parseFloat(formData.qty6mm) || 0;
    const qty8mm = parseFloat(formData.qty8mm) || 0;
    const qty10mm = parseFloat(formData.qty10mm) || 0;
    const qty12mm = parseFloat(formData.qty12mm) || 0;
    const qty16mm = parseFloat(formData.qty16mm) || 0;
    const qty20mm = parseFloat(formData.qty20mm) || 0;
    const qty25mm = parseFloat(formData.qty25mm) || 0;

    if (billMode === 'bill' && !/^\d{10}$/.test(formData.phoneNumber)) {
      Alert.alert('Error', 'Please enter a valid 10-digit phone number.');
      return;
    }

    if (isNaN(basicRate) || basicRate <= 0) {
      Alert.alert('Error', 'Please enter a valid Basic Rate.');
      return;
    }

    let finalRateThin, finalRateThick;

    if (billMode === 'bill') {
      finalRateThin = (basicRate + 6500 + 160) * 1.18 * 0.985;
      finalRateThick = (basicRate + 5500 + 160) * 1.18 * 0.985;
    } else {
      const extra = billMode === 'without' ? -4000 : 0;
      finalRateThin = (basicRate + 6500 + extra + 160) * 0.985 * 1.18;
      finalRateThick = (basicRate + 5500 + extra + 160) * 0.985 * 1.18;
    }

    const total6mm = finalRateThin * qty6mm;
    const total8mm = finalRateThin * qty8mm;
    const total10mm = finalRateThick * qty10mm;
    const total12mm = finalRateThick * qty12mm;
    const total16mm = finalRateThick * qty16mm;
    const total20mm = finalRateThick * qty20mm;
    const total25mm = finalRateThick * qty25mm;

    const subTotal = total6mm + total8mm + total10mm + total12mm + total16mm + total20mm + total25mm;
    const beforeGST = subTotal / 1.18;
    const gstAmount = subTotal - beforeGST;
    const cgst = gstAmount / 2;
    const sgst = gstAmount / 2;

    const calculationResult = {
      mode: billMode,
      customerName: formData.customerName || 'N/A',
      phoneNumber: formData.phoneNumber || '0000000000',
      invoiceDate: formData.invoiceDate || new Date().toISOString().split('T')[0],
      invoiceNumber: formData.invoiceNumber || 'INV-' + Date.now(),
      vehicleNumber: formData.vehicleNumber || 'N/A',
      finalRateThin: finalRateThin.toFixed(2),
      finalRateThick: finalRateThick.toFixed(2),
      quantities: {
        qty6mm, qty8mm, qty10mm, qty12mm, qty16mm, qty20mm, qty25mm
      },
      totals: {
        total6mm: total6mm.toFixed(2),
        total8mm: total8mm.toFixed(2),
        total10mm: total10mm.toFixed(2),
        total12mm: total12mm.toFixed(2),
        total16mm: total16mm.toFixed(2),
        total20mm: total20mm.toFixed(2),
        total25mm: total25mm.toFixed(2),
      },
      beforeGST: beforeGST.toFixed(2),
      cgst: cgst.toFixed(2),
      sgst: sgst.toFixed(2),
      subTotal: subTotal.toFixed(2),
    };

    setResult(calculationResult);
  };

  const handleDownloadPDF = () => {
    if (!result) {
      Alert.alert('Error', 'Please calculate the bill first.');
      return;
    }
    generatePDF(result);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.card}>
        <View style={styles.header}>
          <CalculatorIcon size={24} color="#2563eb" />
          <Text style={styles.headerText}>Steel Rate Calculator</Text>
        </View>

        <View style={styles.formSection}>
          <Text style={styles.label}>Select Mode</Text>
          <View style={styles.pickerContainer}>
            <Picker
              selectedValue={billMode}
              onValueChange={handleModeChange}
              style={styles.picker}
            >
              <Picker.Item label="Bill" value="bill" />
              <Picker.Item label="Without Bill" value="without" />
            </Picker>
          </View>
        </View>

        <View style={styles.formSection}>
          <Text style={styles.sectionTitle}>Customer Details</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Customer Name</Text>
            <TextInput
              style={styles.input}
              value={formData.customerName}
              onChangeText={(text) => setFormData({ ...formData, customerName: text })}
              placeholder="Enter customer name"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Phone Number</Text>
            <TextInput
              style={styles.input}
              value={formData.phoneNumber}
              onChangeText={(text) => setFormData({ ...formData, phoneNumber: text })}
              placeholder="Enter phone number"
              keyboardType="phone-pad"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Invoice Date</Text>
            <TextInput
              style={styles.input}
              value={formData.invoiceDate}
              onChangeText={(text) => setFormData({ ...formData, invoiceDate: text })}
              placeholder="YYYY-MM-DD"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Invoice Number</Text>
            <TextInput
              style={styles.input}
              value={formData.invoiceNumber}
              onChangeText={(text) => setFormData({ ...formData, invoiceNumber: text })}
              placeholder="Enter invoice number"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Vehicle Number</Text>
            <TextInput
              style={styles.input}
              value={formData.vehicleNumber}
              onChangeText={(text) => setFormData({ ...formData, vehicleNumber: text })}
              placeholder="Enter vehicle number"
            />
          </View>
        </View>

        <View style={styles.formSection}>
          <Text style={styles.sectionTitle}>Rate & Quantities</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Basic Rate (₹ per ton)</Text>
            <TextInput
              style={styles.input}
              value={formData.basicRate}
              onChangeText={(text) => setFormData({ ...formData, basicRate: text })}
              placeholder="Enter basic rate"
              keyboardType="numeric"
            />
          </View>

          <View style={styles.quantityGrid}>
            {[
              { size: '6mm', key: 'qty6mm' },
              { size: '8mm', key: 'qty8mm' },
              { size: '10mm', key: 'qty10mm' },
              { size: '12mm', key: 'qty12mm' },
              { size: '16mm', key: 'qty16mm' },
              { size: '20mm', key: 'qty20mm' },
              { size: '25mm', key: 'qty25mm' },
            ].map(({ size, key }) => (
              <View key={key} style={styles.quantityItem}>
                <Text style={styles.quantityLabel}>{size}</Text>
                <TextInput
                  style={styles.quantityInput}
                  value={formData[key as keyof typeof formData]}
                  onChangeText={(text) => setFormData({ ...formData, [key]: text })}
                  placeholder="0.000"
                  keyboardType="numeric"
                />
              </View>
            ))}
          </View>
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.calculateButton} onPress={calculateBill}>
            <CalculatorIcon size={20} color="#ffffff" />
            <Text style={styles.calculateButtonText}>Calculate Bill</Text>
          </TouchableOpacity>

          {result && (
            <TouchableOpacity style={styles.pdfButton} onPress={handleDownloadPDF}>
              <Download size={20} color="#ffffff" />
              <Text style={styles.pdfButtonText}>Download PDF</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {result && <BillResult result={result} />}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
    marginLeft: 8,
  },
  formSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 6,
  },
  pickerContainer: {
    backgroundColor: '#f9fafb',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  picker: {
    height: 50,
  },
  inputGroup: {
    marginBottom: 16,
  },
  input: {
    backgroundColor: '#f9fafb',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    color: '#111827',
  },
  quantityGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -8,
  },
  quantityItem: {
    width: '50%',
    paddingHorizontal: 8,
    marginBottom: 12,
  },
  quantityLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 4,
  },
  quantityInput: {
    backgroundColor: '#f9fafb',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 16,
    color: '#111827',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  calculateButton: {
    backgroundColor: '#2563eb',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: 8,
    justifyContent: 'center',
  },
  calculateButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  pdfButton: {
    backgroundColor: '#f97316',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginLeft: 8,
    justifyContent: 'center',
  },
  pdfButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
});