import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';
import { User, Mail, Phone, Lock, Eye, EyeOff, Gift, Calendar } from 'lucide-react-native';
import { useAuth } from '../hooks/useAuth';

export function AuthScreen() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
  });

  const { login, register, resetPassword } = useAuth();

  const handleSubmit = async () => {
    console.log('Submit button pressed, isLogin:', isLogin);
    console.log('Form data:', formData);
    
    if (isLogin) {
      if (!formData.email || !formData.password) {
        Alert.alert('Error', 'Please fill in all required fields');
        return;
      }
      await login(formData.email, formData.password);
    } else {
      if (!formData.name || !formData.email || !formData.phone || !formData.password) {
        Alert.alert('Error', 'Please fill in all required fields');
        return;
      }
      await register(formData.name, formData.email, formData.phone, formData.password);
    }
  };

  const handleDemoLogin = () => {
    // Demo login for testing the app functionality
    setFormData({
      name: 'Demo User',
      email: 'demo@example.com',
      phone: '9876543210',
      password: 'demo123',
    });
  };

  const handleForgotPassword = async () => {
    if (!formData.email) {
      Alert.alert('Error', 'Please enter your email address');
      return;
    }
    await resetPassword(formData.email);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.logoContainer}>
        <View style={styles.logoIcon}>
          <User size={40} color="#2563eb" />
        </View>
        <Text style={styles.appTitle}>Steel Rate Calculator</Text>
        <Text style={styles.appSubtitle}>Jalna</Text>
      </View>

      <View style={styles.trialBanner}>
        <Gift size={20} color="#f97316" />
        <Text style={styles.trialText}>3 Days Free Trial</Text>
        <Calendar size={16} color="#f97316" />
      </View>

      <View style={styles.card}>
        <Text style={styles.title}>{isLogin ? 'Login' : 'Register'}</Text>
        <Text style={styles.subtitle}>
          {isLogin ? 'Welcome back! (Demo Mode)' : 'Start your 3-day free trial (Demo Mode)'}
        </Text>

        <TouchableOpacity style={styles.demoButton} onPress={handleDemoLogin}>
          <Text style={styles.demoButtonText}>Try Demo Login</Text>
        </TouchableOpacity>

        {!isLogin && (
          <View style={styles.inputContainer}>
            <User size={20} color="#6b7280" />
            <TextInput
              style={styles.input}
              placeholder="Name"
              value={formData.name}
              onChangeText={(text) => setFormData({ ...formData, name: text })}
            />
          </View>
        )}

        <View style={styles.inputContainer}>
          <Mail size={20} color="#6b7280" />
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={formData.email}
            onChangeText={(text) => setFormData({ ...formData, email: text })}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        {!isLogin && (
          <View style={styles.inputContainer}>
            <Phone size={20} color="#6b7280" />
            <TextInput
              style={styles.input}
              placeholder="Phone Number"
              value={formData.phone}
              onChangeText={(text) => setFormData({ ...formData, phone: text })}
              keyboardType="phone-pad"
            />
          </View>
        )}

        <View style={styles.inputContainer}>
          <Lock size={20} color="#6b7280" />
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={formData.password}
            onChangeText={(text) => setFormData({ ...formData, password: text })}
            secureTextEntry={!showPassword}
          />
          <TouchableOpacity
            onPress={() => setShowPassword(!showPassword)}
            style={styles.eyeIcon}
          >
            {showPassword ? (
              <EyeOff size={20} color="#6b7280" />
            ) : (
              <Eye size={20} color="#6b7280" />
            )}
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>
            {isLogin ? 'Login' : 'Register'}
          </Text>
        </TouchableOpacity>

        {isLogin && (
          <TouchableOpacity
            style={styles.forgotPasswordButton}
            onPress={handleForgotPassword}
          >
            <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
          </TouchableOpacity>
        )}

        <View style={styles.switchContainer}>
          <Text style={styles.switchText}>
            {isLogin ? "Don't have an account?" : 'Already have an account?'}
          </Text>
          <TouchableOpacity onPress={() => setIsLogin(!isLogin)}>
            <Text style={styles.switchLink}>
              {isLogin ? 'Register' : 'Login'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.subscriptionInfo}>
        <Text style={styles.subscriptionTitle}>After Free Trial</Text>
        <Text style={styles.subscriptionPrice}>₹2000/year</Text>
        <Text style={styles.productionNote}>
          * Production version requires backend integration
        </Text>
        <Text style={styles.subscriptionFeatures}>
          • Complete steel rate calculations{'\n'}
          • GST calculations with breakdown{'\n'}
          • Invoice generation & PDF export{'\n'}
          • Multiple calculation modes
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    padding: 20,
    minHeight: '100%',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 32,
    marginTop: 20,
  },
  logoIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#eff6ff',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  appTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#111827',
    textAlign: 'center',
  },
  appSubtitle: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    marginTop: 4,
  },
  trialBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff7ed',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#fed7aa',
  },
  trialText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#f97316',
    marginHorizontal: 8,
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#111827',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6b7280',
    textAlign: 'center',
    marginBottom: 32,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
    marginLeft: 12,
  },
  eyeIcon: {
    padding: 4,
  },
  submitButton: {
    backgroundColor: '#2563eb',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 16,
  },
  submitButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  forgotPasswordButton: {
    alignItems: 'center',
    marginBottom: 16,
  },
  forgotPasswordText: {
    color: '#f97316',
    fontSize: 14,
    fontWeight: '500',
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  switchText: {
    color: '#6b7280',
    fontSize: 14,
    marginRight: 4,
  },
  switchLink: {
    color: '#2563eb',
    fontSize: 14,
    fontWeight: '600',
  },
  subscriptionInfo: {
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 20,
    marginTop: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    alignItems: 'center',
  },
  subscriptionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 8,
  },
  subscriptionPrice: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2563eb',
    marginBottom: 12,
  },
  subscriptionFeatures: {
    fontSize: 14,
    color: '#6b7280',
    textAlign: 'center',
    lineHeight: 20,
  },
  demoButton: {
    backgroundColor: '#f97316',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 20,
    alignItems: 'center',
    marginBottom: 16,
  },
  demoButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  productionNote: {
    fontSize: 12,
    color: '#f97316',
    textAlign: 'center',
    fontStyle: 'italic',
    marginBottom: 8,
  },
});