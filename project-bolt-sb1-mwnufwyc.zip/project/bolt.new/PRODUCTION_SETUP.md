# Steel Rate Calculator - Production Setup Guide

## What Bolt.ai Built (Frontend)

✅ **Complete React Native Mobile App**
- Professional UI/UX design
- Steel rate calculation logic (exact formulas from your code)
- 3-day trial system (frontend logic)
- User authentication screens
- PDF generation functionality
- Tab navigation (Calculator, Profile, Settings)
- Form validation and error handling

## What You Need for Production (Backend)

### 1. Authentication System
**Current**: Demo authentication (simulated)
**Needed**: Real user authentication

**Options**:
- **Firebase Authentication** (Recommended - easiest)
  - Email/password authentication
  - User management
  - Password reset functionality
  
- **Supabase Authentication** (Alternative)
  - Similar to Firebase but open source
  
- **Custom Backend** (Node.js/Express + MongoDB/PostgreSQL)

### 2. Subscription Management
**Current**: Simulated subscription status
**Needed**: Real payment processing

**Required**:
- **Razorpay Integration** (for Indian payments)
  - ₹2000/year subscription plans
  - Payment gateway integration
  - Subscription status tracking
  
- **RevenueCat** (Recommended for mobile subscriptions)
  - Handles App Store/Play Store billing
  - Subscription management
  - Receipt validation

### 3. Database
**Current**: Local state management
**Needed**: Persistent data storage

**Required Tables**:
- Users (id, name, email, phone, created_at)
- Subscriptions (user_id, plan, start_date, end_date, status)
- Calculations (user_id, calculation_data, created_at)
- Invoices (user_id, invoice_number, data, created_at)

### 4. Backend API
**Needed**: Server to handle business logic

**Required Endpoints**:
```
POST /auth/register
POST /auth/login
POST /auth/forgot-password
GET /user/profile
POST /subscription/create
GET /subscription/status
POST /calculations/save
GET /calculations/history
POST /invoices/generate
```

## Deployment Options

### Mobile App Deployment
1. **Expo Application Services (EAS)**
   - Build and submit to App Store/Play Store
   - Handles certificates and provisioning

2. **Manual Build**
   - Export to native iOS/Android projects
   - Build and submit manually

### Backend Deployment
1. **Firebase** (Easiest)
   - Authentication + Firestore database
   - Cloud Functions for business logic
   
2. **Supabase** (Open source alternative)
   - PostgreSQL database
   - Built-in authentication
   - Edge functions

3. **Traditional Hosting**
   - AWS/Google Cloud/Azure
   - Node.js backend with database

## Next Steps for Production

1. **Choose Backend Solution**
   - Firebase (recommended for quick setup)
   - Supabase (for more control)
   - Custom backend (for full customization)

2. **Set Up Payment Processing**
   - Integrate Razorpay for web payments
   - Use RevenueCat for mobile subscriptions

3. **Database Design**
   - Create user and subscription tables
   - Set up data relationships

4. **API Development**
   - Build authentication endpoints
   - Create subscription management APIs
   - Implement calculation storage

5. **Mobile App Updates**
   - Replace demo auth with real API calls
   - Add proper error handling
   - Implement offline functionality

## Cost Estimates

**Monthly Costs**:
- Firebase: ₹0-₹2000 (depending on usage)
- Razorpay: 2% transaction fee
- RevenueCat: Free up to $10k revenue
- App Store: $99/year (iOS)
- Play Store: $25 one-time (Android)

## Technical Requirements

**Skills Needed**:
- Backend development (Node.js/Firebase)
- Database design
- Payment gateway integration
- Mobile app deployment
- API development

**Timeline**: 2-4 weeks for full production setup

---

The current Bolt.ai app provides a complete, professional frontend that demonstrates all functionality. For production, you'll need to replace the demo authentication and subscription logic with real backend services.