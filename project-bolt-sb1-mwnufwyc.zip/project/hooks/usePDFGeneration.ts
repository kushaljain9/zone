import { Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';

export function usePDFGeneration() {
  const generatePDF = async (result: any) => {
    try {
      // In a real app, you would use a PDF generation library like react-native-pdf-lib
      // For demo purposes, we'll create a text file with the bill details
      
      const billContent = generateBillContent(result);
      const fileName = `Steel_Rate_${result.invoiceNumber}_${Date.now()}.txt`;
      const filePath = FileSystem.documentDirectory + fileName;
      
      await FileSystem.writeAsStringAsync(filePath, billContent);
      
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(filePath);
      } else {
        Alert.alert('Success', `Bill saved to: ${filePath}`);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to generate PDF. Please try again.');
    }
  };

  const generateBillContent = (result: any) => {
    const { mode, quantities, totals } = result;
    
    let content = `STEEL RATE CALCULATOR - JALNA\n`;
    content += `=====================================\n\n`;
    
    if (mode !== 'onlyrate') {
      content += `INVOICE DETAILS:\n`;
      content += `Invoice Number: ${result.invoiceNumber}\n`;
      content += `Date: ${result.invoiceDate}\n`;
      content += `Customer Name: ${result.customerName}\n`;
      content += `Phone: ${result.phoneNumber}\n`;
      content += `Vehicle No: ${result.vehicleNumber}\n\n`;
    }
    
    content += `RATES:\n`;
    content += `6–8mm Rate: ₹${result.finalRateThin}\n`;
    content += `10–25mm Rate: ₹${result.finalRateThick}\n\n`;
    
    content += `QUANTITIES & TOTALS:\n`;
    [
      { size: '6mm', qty: quantities.qty6mm, total: totals.total6mm },
      { size: '8mm', qty: quantities.qty8mm, total: totals.total8mm },
      { size: '10mm', qty: quantities.qty10mm, total: totals.total10mm },
      { size: '12mm', qty: quantities.qty12mm, total: totals.total12mm },
      { size: '16mm', qty: quantities.qty16mm, total: totals.total16mm },
      { size: '20mm', qty: quantities.qty20mm, total: totals.total20mm },
      { size: '25mm', qty: quantities.qty25mm, total: totals.total25mm },
    ].forEach(({ size, qty, total }) => {
      if (qty > 0) {
        content += `${size}: ${qty} tons = ₹${total}\n`;
      }
    });
    
    if (mode !== 'onlyrate') {
      content += `\nGST BREAKDOWN:\n`;
      content += `Amount Before GST: ₹${result.beforeGST}\n`;
      content += `CGST (9%): ₹${result.cgst}\n`;
      content += `SGST (9%): ₹${result.sgst}\n`;
      content += `Total Amount: ₹${result.subTotal}\n`;
    }
    
    content += `\n=====================================\n`;
    content += `Generated on: ${new Date().toLocaleString()}\n`;
    
    return content;
  };

  return { generatePDF };
}