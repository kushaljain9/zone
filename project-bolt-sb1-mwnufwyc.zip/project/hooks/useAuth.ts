import { useState, useEffect } from 'react';
import { Alert } from 'react-native';

interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  subscriptionActive: boolean;
  subscriptionEndDate?: string;
  trialStartDate?: string;
  trialEndDate?: string;
  isTrialActive?: boolean;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isSubscriptionActive, setIsSubscriptionActive] = useState(false);
  const [isTrialActive, setIsTrialActive] = useState(false);

  useEffect(() => {
    // Check for stored user data
    checkAuthState();
  }, []);

  const checkAuthState = () => {
    // In a real app, this would check AsyncStorage or Firebase auth state
    // For demo purposes, we'll start with no user logged in
    setUser(null);
    setIsAuthenticated(false);
    setIsSubscriptionActive(false);
    setIsTrialActive(false);
  };

  const calculateTrialStatus = (trialStartDate: string) => {
    const startDate = new Date(trialStartDate);
    const endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 3); // 3 days trial
    
    const now = new Date();
    const isActive = now <= endDate;
    
    return {
      isActive,
      endDate: endDate.toISOString().split('T')[0],
    };
  };

  const login = async (email: string, password: string) => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo purposes, we'll simulate a successful login
      const trialStart = '2024-01-15'; // Simulate trial start date
      const trialStatus = calculateTrialStatus(trialStart);
      
      const simulatedUser = {
        id: '1',
        name: 'Demo User',
        email: email,
        phone: '9876543210',
        subscriptionActive: false,
        subscriptionEndDate: undefined,
        trialStartDate: trialStart,
        trialEndDate: trialStatus.endDate,
        isTrialActive: trialStatus.isActive,
      };

      setUser(simulatedUser);
      setIsAuthenticated(true);
      setIsSubscriptionActive(simulatedUser.subscriptionActive);
      setIsTrialActive(simulatedUser.isTrialActive || false);
      
      Alert.alert('Success', 'Login successful!');
    } catch (error) {
      Alert.alert('Error', 'Login failed. Please try again.');
    }
  };

  const register = async (name: string, email: string, phone: string, password: string) => {
    try {
      // Basic validation
      if (!name.trim() || !email.trim() || !phone.trim() || !password.trim()) {
        Alert.alert('Error', 'Please fill in all fields');
        return;
      }
      
      if (!/^\S+@\S+\.\S+$/.test(email)) {
        Alert.alert('Error', 'Please enter a valid email address');
        return;
      }
      
      if (!/^\d{10}$/.test(phone)) {
        Alert.alert('Error', 'Please enter a valid 10-digit phone number');
        return;
      }
      
      if (password.length < 6) {
        Alert.alert('Error', 'Password must be at least 6 characters long');
        return;
      }
      
      // For demo purposes, we'll simulate a successful registration
      const trialStart = new Date().toISOString().split('T')[0];
      const trialStatus = calculateTrialStatus(trialStart);
      
      const newUser = {
        id: Date.now().toString(),
        name,
        email,
        phone,
        subscriptionActive: false,
        subscriptionEndDate: undefined,
        trialStartDate: trialStart,
        trialEndDate: trialStatus.endDate,
        isTrialActive: trialStatus.isActive,
      };

      setUser(newUser);
      setIsAuthenticated(true);
      setIsSubscriptionActive(false);
      setIsTrialActive(newUser.isTrialActive);
      
      Alert.alert('Success', 'Registration successful! Your 3-day free trial has started.');
    } catch (error) {
      console.error('Registration error:', error);
      Alert.alert('Error', 'Registration failed. Please try again.');
    }
  };

  const resetPassword = async (email: string) => {
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      Alert.alert('Success', 'Password reset email sent!');
    } catch (error) {
      Alert.alert('Error', 'Failed to send reset email. Please try again.');
    }
  };

  const startSubscription = async () => {
    try {
      Alert.alert(
        'Payment Demo',
        'In a real app, this would open Razorpay payment gateway for ₹2000/year subscription.',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Simulate Success', 
            onPress: () => {
              setIsSubscriptionActive(true);
              setIsTrialActive(false);
              if (user) {
                setUser({
                  ...user,
                  subscriptionActive: true,
                  subscriptionEndDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                  isTrialActive: false,
                });
              }
              Alert.alert('Success', 'Subscription activated successfully!');
            }
          },
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Payment failed. Please try again.');
    }
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setIsSubscriptionActive(false);
    setIsTrialActive(false);
  };

  return {
    user,
    isAuthenticated,
    isSubscriptionActive,
    isTrialActive,
    subscriptionEndDate: user?.subscriptionEndDate,
    trialEndDate: user?.trialEndDate,
    login,
    register,
    resetPassword,
    startSubscription,
    logout,
  };
}