import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Platform,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Info, CircleHelp as HelpCircle, Mail, Phone } from 'lucide-react-native';

export default function SettingsScreen() {
  const handleSupport = () => {
    Alert.alert(
      'Support',
      'Contact us for support:\n\nEmail: support@steelcalculator.com\nPhone: +91 9876543210'
    );
  };

  const handleAbout = () => {
    Alert.alert(
      'About',
      'Steel Rate Calculator - Jalna\n\nVersion 1.0.0\n\nA comprehensive tool for calculating steel rates with GST calculations and invoice generation.'
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Settings</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Information</Text>
          
          <TouchableOpacity style={styles.settingItem} onPress={handleAbout}>
            <Info size={24} color="#2563eb" />
            <Text style={styles.settingText}>About</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingItem} onPress={handleSupport}>
            <HelpCircle size={24} color="#2563eb" />
            <Text style={styles.settingText}>Support</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contact</Text>
          
          <TouchableOpacity style={styles.settingItem}>
            <Mail size={24} color="#2563eb" />
            <Text style={styles.settingText}>support@steelcalculator.com</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.settingItem}>
            <Phone size={24} color="#2563eb" />
            <Text style={styles.settingText}>+91 9876543210</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Steel Rate Calculator - Jalna
          </Text>
          <Text style={styles.versionText}>Version 1.0.0</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#2563eb',
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  settingText: {
    fontSize: 16,
    color: '#374151',
    marginLeft: 12,
  },
  footer: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingBottom: 20,
  },
  footerText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#6b7280',
    marginBottom: 4,
  },
  versionText: {
    fontSize: 14,
    color: '#9ca3af',
  },
});