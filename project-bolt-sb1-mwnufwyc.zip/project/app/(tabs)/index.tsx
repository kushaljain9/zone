import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Platform,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { AuthScreen } from '../../components/AuthScreen';
import { SubscriptionScreen } from '../../components/SubscriptionScreen';
import { Calculator } from '../../components/Calculator';
import { useAuth } from '../../hooks/useAuth';

export default function HomeScreen() {
  const { user, isAuthenticated, isSubscriptionActive, isTrialActive } = useAuth();

  const renderContent = () => {
    if (!isAuthenticated) {
      return <AuthScreen />;
    }

    if (!isSubscriptionActive && !isTrialActive) {
      return <SubscriptionScreen />;
    }

    return <Calculator />;
  };

  return (
    <View style={styles.container}>
      <StatusBar style="dark" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Steel Rate Calculator</Text>
        <Text style={styles.headerSubtitle}>Jalna</Text>
      </View>
      
      <View style={styles.content}>
        {renderContent()}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#2563eb',
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#bfdbfe',
    marginTop: 4,
  },
  content: {
    flex: 1,
  },
});